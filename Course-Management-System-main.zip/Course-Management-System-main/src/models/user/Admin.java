package models.user;

public class Admin extends SystemUser {

	public Admin(String name) {
		super(name, "Admin");
	}
}
